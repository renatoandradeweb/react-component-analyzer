import { useState, useEffect } from 'react';

/**
 * Hook personalizado para buscar dados de uma API
 * @param {string} url - URL para a requisição
 * @param {Object} options - Opções adicionais para fetch
 * @returns {Object} { data, loading, error, refetch }
 */
export const useDataFetching = (url, options = {}) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchData = async () => {
        try {
            setLoading(true);
            setError(null);

            // Simular um atraso para demonstração
            if (process.env.NODE_ENV === 'development') {
                await new Promise(resolve => setTimeout(resolve, 1000));
            }

            const response = await fetch(url, options);

            if (!response.ok) {
                throw new Error(`Request failed with status ${response.status}`);
            }

            const jsonData = await response.json();
            setData(jsonData);
        } catch (err) {
            setError(err.message || 'Ocorreu um erro ao buscar os dados');
            console.error('Fetch error:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [url]);

    return { data, loading, error, refetch: fetchData };
};

export default useDataFetching;