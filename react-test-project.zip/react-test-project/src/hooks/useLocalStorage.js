import { useState, useEffect } from 'react';

/**
 * Hook personalizado para trabalhar com localStorage
 * @param {string} key - Chave para usar no localStorage
 * @param {any} initialValue - Valor inicial se a chave não existir
 * @returns {Array} [storedValue, setValue]
 */
export const useLocalStorage = (key, initialValue) => {
    // Função para obter valor inicial do localStorage ou usar o valor padrão
    const getInitialValue = () => {
        try {
            const item = window.localStorage.getItem(key);
            return item ? JSON.parse(item) : initialValue;
        } catch (error) {
            console.error('Error reading from localStorage:', error);
            return initialValue;
        }
    };

    // Estado para armazenar o valor atual
    const [storedValue, setStoredValue] = useState(getInitialValue);

    // Função para atualizar o valor no estado e no localStorage
    const setValue = (value) => {
        try {
            // Permitir que o valor seja uma função, como no useState
            const valueToStore = value instanceof Function ? value(storedValue) : value;

            // Salvar no estado
            setStoredValue(valueToStore);

            // Salvar no localStorage
            if (valueToStore === undefined) {
                window.localStorage.removeItem(key);
            } else {
                window.localStorage.setItem(key, JSON.stringify(valueToStore));
            }
        } catch (error) {
            console.error('Error writing to localStorage:', error);
        }
    };

    // Escutar por mudanças na chave em outras abas/janelas
    useEffect(() => {
        const handleStorageChange = (e) => {
            if (e.key === key) {
                setStoredValue(e.newValue ? JSON.parse(e.newValue) : initialValue);
            }
        };

        // Adicionar event listener
        window.addEventListener('storage', handleStorageChange);

        // Limpar event listener
        return () => {
            window.removeEventListener('storage', handleStorageChange);
        };
    }, [key, initialValue]);

    return [storedValue, setValue];

};
export default useLocalStorage;