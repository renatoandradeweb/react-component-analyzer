import React from 'react';
import { Paper, Box } from '@mui/material';
import { styled } from '@mui/material/styles';

const StyledPaper = styled(Paper)(({ theme }) => ({
    padding: theme.spacing(3),
    textAlign: 'center',
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center'
}));

export const Card = ({ children, ...props }) => {
    return (
        <StyledPaper elevation={2} {...props}>
            <Box>
                {children}
            </Box>
        </StyledPaper>
    );
};

export default Card;