import React, { useState, useEffect } from 'react';
import { Grid, Paper, Typography, Box, Divider } from '@mui/material';
import { Card } from './Card';

// Dados simulados
const dashboardData = {
    stats: [
        { id: 1, title: 'Usuários', value: 1234, change: '+12%' },
        { id: 2, title: 'Receita', value: 'R$ 8.345', change: '+8%' },
        { id: 3, title: 'Tarefas', value: 42, change: '-5%' },
        { id: 4, title: 'Projetos', value: 12, change: '0%' }
    ],
    recentActivity: [
        { id: 1, action: 'Novo usuário registrado', time: '5 minutos atrás' },
        { id: 2, action: 'Tarefa concluída', time: '1 hora atrás' },
        { id: 3, action: 'Projeto finalizado', time: '2 horas atrás' }
    ]
};

const Dashboard = () => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simulando uma chamada de API
        const fetchData = async () => {
            try {
                // Em um caso real, aqui seria uma chamada fetch ou axios
                await new Promise(resolve => setTimeout(resolve, 1000));
                setData(dashboardData);
                setLoading(false);
            } catch (error) {
                console.error('Erro ao carregar dados:', error);
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    if (loading) {
        return <Typography>Carregando...</Typography>;
    }

    return (
        <Box sx={{ flexGrow: 1, p: 2 }}>
            <Typography variant="h4" gutterBottom>
                Dashboard
            </Typography>

            <Grid container spacing={3}>
                {data.stats.map(stat => (
                    <Grid item xs={12} sm={6} md={3} key={stat.id}>
                        <Card>
                            <Typography variant="h6">{stat.title}</Typography>
                            <Typography variant="h4">{stat.value}</Typography>
                            <Typography
                                variant="body2"
                                color={stat.change.startsWith('+') ? 'success.main' : stat.change.startsWith('-') ? 'error.main' : 'text.secondary'}
                            >
                                {stat.change}
                            </Typography>
                        </Card>
                    </Grid>
                ))}
            </Grid>

            <Paper sx={{ p: 2, mt: 3 }}>
                <Typography variant="h6" gutterBottom>
                    Atividades Recentes
                </Typography>
                <Divider sx={{ mb: 2 }} />
                {data.recentActivity.map((activity, index) => (
                    <Box key={activity.id} sx={{ mb: 1.5 }}>
                        <Grid container justifyContent="space-between">
                            <Grid item>
                                <Typography variant="body1">{activity.action}</Typography>
                            </Grid>
                            <Grid item>
                                <Typography variant="body2" color="text.secondary">
                                    {activity.time}
                                </Typography>
                            </Grid>
                        </Grid>
                        {index < data.recentActivity.length - 1 && <Divider sx={{ mt: 1.5 }} />}
                    </Box>
                ))}
            </Paper>
        </Box>
    );
};

export default Dashboard;