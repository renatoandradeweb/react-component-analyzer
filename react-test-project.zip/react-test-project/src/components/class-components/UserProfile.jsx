import React, { Component } from 'react';
import { Card, CardContent, Avatar, Typography, Box, Button } from '@mui/material';
import { styled } from '@mui/material/styles';

const ProfileAvatar = styled(Avatar)(({ theme }) => ({
    width: theme.spacing(10),
    height: theme.spacing(10),
    marginBottom: theme.spacing(2)
}));

class UserProfile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: {
                name: 'João Silva',
                role: 'Desenvolvedor Frontend',
                avatar: 'https://via.placeholder.com/150',
                bio: 'Desenvolvedor web com experiência em React, Next.js e TypeScript.'
            },
            isEditing: false
        };
    }

    toggleEdit = () => {
        this.setState(prevState => ({
            isEditing: !prevState.isEditing
        }));
    }

    render() {
        const { user, isEditing } = this.state;

        return (
            <Card sx={{ maxWidth: 400, margin: '0 auto', marginTop: 4 }}>
                <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <ProfileAvatar src={user.avatar} alt={user.name} />
                    <Typography variant="h5" component="div">
                        {user.name}
                    </Typography>
                    <Typography variant="subtitle1" color="text.secondary">
                        {user.role}
                    </Typography>
                    <Box sx={{ mt: 2, textAlign: 'center' }}>
                        <Typography variant="body2">
                            {user.bio}
                        </Typography>
                    </Box>
                    <Box sx={{ mt: 2 }}>
                        <Button
                            variant="contained"
                            color={isEditing ? "secondary" : "primary"}
                            onClick={this.toggleEdit}
                        >
                            {isEditing ? 'Cancelar' : 'Editar Perfil'}
                        </Button>
                    </Box>
                </CardContent>
            </Card>
        );
    }
}

export default UserProfile;