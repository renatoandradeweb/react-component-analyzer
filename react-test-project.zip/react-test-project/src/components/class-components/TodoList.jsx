import React, { Component } from 'react';
import {
    List,
    ListItem,
    ListItemText,
    ListItemIcon,
    Checkbox,
    TextField,
    Button,
    Box,
    Paper,
    Typography,
    IconButton
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

class TodoList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            todos: [
                { id: 1, text: 'Aprender React', completed: true },
                { id: 2, text: 'Criar componentes reutilizáveis', completed: false },
                { id: 3, text: 'Implementar APIs', completed: false }
            ],
            newTodo: ''
        };
    }

    handleToggle = (id) => {
        this.setState(prevState => ({
            todos: prevState.todos.map(todo =>
                todo.id === id ? { ...todo, completed: !todo.completed } : todo
            )
        }));
    };

    handleDelete = (id) => {
        this.setState(prevState => ({
            todos: prevState.todos.filter(todo => todo.id !== id)
        }));
    };

    handleInputChange = (e) => {
        this.setState({ newTodo: e.target.value });
    };

    handleAddTodo = () => {
        if (!this.state.newTodo.trim()) return;

        const newTodo = {
            id: Date.now(),
            text: this.state.newTodo,
            completed: false
        };

        this.setState(prevState => ({
            todos: [...prevState.todos, newTodo],
            newTodo: ''
        }));
    };

    render() {
        const { todos, newTodo } = this.state;

        return (
            <Paper sx={{ maxWidth: 500, margin: '0 auto', marginTop: 4, p: 2 }}>
                <Typography variant="h5" component="h2" gutterBottom>
                    Lista de Tarefas
                </Typography>

                <Box sx={{ display: 'flex', mb: 2 }}>
                    <TextField
                        fullWidth
                        value={newTodo}
                        onChange={this.handleInputChange}
                        placeholder="Nova tarefa"
                        variant="outlined"
                        size="small"
                    />
                    <Button
                        variant="contained"
                        onClick={this.handleAddTodo}
                        sx={{ ml: 1 }}
                    >
                        Adicionar
                    </Button>
                </Box>

                <List>
                    {todos.map((todo) => (
                        <ListItem
                            key={todo.id}
                            secondaryAction={
                                <IconButton edge="end" onClick={() => this.handleDelete(todo.id)}>
                                    <DeleteIcon />
                                </IconButton>
                            }
                        >
                            <ListItemIcon>
                                <Checkbox
                                    edge="start"
                                    checked={todo.completed}
                                    onChange={() => this.handleToggle(todo.id)}
                                />
                            </ListItemIcon>
                            <ListItemText
                                primary={todo.text}
                                sx={{
                                    textDecoration: todo.completed ? 'line-through' : 'none',
                                    color: todo.completed ? 'text.disabled' : 'text.primary'
                                }}
                            />
                        </ListItem>
                    ))}
                </List>
            </Paper>
        );
    }
}

export default TodoList;