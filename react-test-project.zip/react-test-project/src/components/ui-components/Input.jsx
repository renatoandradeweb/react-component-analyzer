import React, { forwardRef } from 'react';
import styled from 'styled-components';

const InputWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 16px;
`;

const Label = styled.label`
  font-size: 14px;
  margin-bottom: 8px;
  color: #333;
`;

const StyledInput = styled.input`
  padding: 8px 12px;
  border: 1px solid ${props => props.error ? '#f44336' : '#ccc'};
  border-radius: 4px;
  font-size: 14px;
  transition: border-color 0.3s ease;
  outline: none;
  
  &:focus {
    border-color: ${props => props.error ? '#f44336' : '#1976d2'};
    box-shadow: 0 0 0 2px ${props => props.error ? 'rgba(244, 67, 54, 0.2)' : 'rgba(25, 118, 210, 0.2)'};
  }
  
  &:disabled {
    background-color: #f5f5f5;
    cursor: not-allowed;
  }
`;

const ErrorMessage = styled.span`
  color: #f44336;
  font-size: 12px;
  margin-top: 4px;
`;

export const Input = forwardRef(({
                                     label,
                                     error,
                                     errorMessage,
                                     ...props
                                 }, ref) => {
    return (
        <InputWrapper>
            {label && <Label>{label}</Label>}
            <StyledInput ref={ref} error={error} {...props} />
            {error && errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}
        </InputWrapper>
    );
});

export default Input;