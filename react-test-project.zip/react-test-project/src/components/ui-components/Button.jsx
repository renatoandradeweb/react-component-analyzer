import React from 'react';
import styled from 'styled-components';

// Exemplo de Componente usando styled-components
const StyledButton = styled.button`
  padding: 8px 16px;
  font-size: 14px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  border: none;
  outline: none;
  
  /* Variants */
  background-color: ${props => {
    if (props.variant === 'primary') return '#1976d2';
    if (props.variant === 'secondary') return '#dc004e';
    if (props.variant === 'success') return '#4caf50';
    if (props.variant === 'warning') return '#ff9800';
    if (props.variant === 'danger') return '#f44336';
    return '#e0e0e0';
}};
  
  color: ${props => {
    if (props.variant && props.variant !== 'default') return 'white';
    return '#333';
}};
  
  &:hover {
    opacity: 0.8;
    transform: translateY(-2px);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  }
  
  &:active {
    transform: translateY(0);
    box-shadow: none;
  }
  
  &:disabled {
    background-color: #bdbdbd;
    color: #757575;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`;

export const Button = ({ children, variant = 'default', ...props }) => {
    return (
        <StyledButton variant={variant} {...props}>
            {children}
        </StyledButton>
    );
};

export default Button;