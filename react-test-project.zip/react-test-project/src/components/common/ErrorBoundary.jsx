import React, { Component } from 'react';
import { Box, Typography, Button, Paper } from '@mui/material';

class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = {
            hasError: false,
            error: null,
            errorInfo: null
        };
    }

    static getDerivedStateFromError(error) {
        // Atualiza o state para que a próxima renderização mostre a UI alternativa
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        // Você também pode registrar o erro em um serviço de relatório de erros
        this.setState({
            error: error,
            errorInfo: errorInfo
        });
        console.error("Error caught by ErrorBoundary:", error, errorInfo);
    }

    handleReset = () => {
        this.setState({
            hasError: false,
            error: null,
            errorInfo: null
        });
        // Redirecionar para a página inicial ou recarregar a aplicação
        window.location.href = '/';
    }

    render() {
        if (this.state.hasError) {
            // Você pode renderizar qualquer UI alternativa
            return (
                <Box
                    sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        height: '100vh',
                        p: 3
                    }}
                >
                    <Paper
                        elevation={3}
                        sx={{
                            maxWidth: 500,
                            width: '100%',
                            p: 4,
                            textAlign: 'center'
                        }}
                    >
                        <Typography variant="h5" color="error" gutterBottom>
                            Algo deu errado
                        </Typography>

                        <Typography variant="body1" paragraph>
                            Desculpe, ocorreu um erro na aplicação.
                        </Typography>

                        {process.env.NODE_ENV === 'development' && this.state.error && (
                            <Box sx={{ mt: 2, mb: 3, textAlign: 'left' }}>
                                <Typography variant="subtitle2">
                                    Detalhes do erro (apenas em ambiente de desenvolvimento):
                                </Typography>
                                <Box
                                    component="pre"
                                    sx={{
                                        mt: 1,
                                        p: 2,
                                        bgcolor: '#f5f5f5',
                                        borderRadius: 1,
                                        overflow: 'auto',
                                        fontSize: '0.8rem'
                                    }}
                                >
                                    {this.state.error.toString()}
                                    <br />
                                    {this.state.errorInfo && this.state.errorInfo.componentStack}
                                </Box>
                            </Box>
                        )}

                        <Button
                            variant="contained"
                            color="primary"
                            onClick={this.handleReset}
                        >
                            Voltar para página inicial
                        </Button>
                    </Paper>
                </Box>
            );
        }

        return this.props.children;
    }
}

export default ErrorBoundary;