import React from 'react';
import { CircularProgress, Box, Typography } from '@mui/material';

export const Loader = ({ message = 'Carregando...' }) => {
    return (
        <Box
            sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
                padding: 3
            }}
        >
            <CircularProgress size={40} />
            {message && (
                <Typography variant="body2" sx={{ mt: 2 }}>
                    {message}
                </Typography>
            )}
        </Box>
    );
};

export default Loader;