import React from 'react';
import { Container, Typography, Paper, Box, Grid, Divider } from '@mui/material';
import { Button } from '../components/ui-components/Button';
import { Input } from '../components/ui-components/Input';

const About = () => {
    return (
        <Container maxWidth="md">
            <Box sx={{ my: 4 }}>
                <Typography variant="h4" component="h1" gutterBottom align="center">
                    Sobre o Projeto
                </Typography>
            </Box>

            <Paper sx={{ p: 3, mb: 4 }}>
                <Typography variant="h6" gutterBottom>
                    O que é este projeto?
                </Typography>
                <Typography variant="body1" paragraph>
                    Este é um projeto de demonstração criado para mostrar diferentes tipos de componentes React.
                    O objetivo é fornecer exemplos de componentes baseados em classe, componentes funcionais,
                    componentes que usam hooks, e componentes estilizados com diferentes bibliotecas.
                </Typography>
                <Typography variant="body1" paragraph>
                    Você pode usar este projeto como referência para entender diferentes padrões de componentes
                    ou como base para seus próprios projetos React.
                </Typography>
            </Paper>

            <Typography variant="h5" gutterBottom>
                Exemplos de Componentes Estilizados
            </Typography>
            <Typography variant="subtitle2" gutterBottom color="text.secondary">
                Componentes criados com styled-components
            </Typography>

            <Box sx={{ mb: 4 }}>
                <Grid container spacing={2} sx={{ mb: 3 }}>
                    <Grid item>
                        <Button variant="primary">Primário</Button>
                    </Grid>
                    <Grid item>
                        <Button variant="secondary">Secundário</Button>
                    </Grid>
                    <Grid item>
                        <Button variant="success">Sucesso</Button>
                    </Grid>
                    <Grid item>
                        <Button variant="warning">Aviso</Button>
                    </Grid>
                    <Grid item>
                        <Button variant="danger">Perigo</Button>
                    </Grid>
                    <Grid item>
                        <Button>Padrão</Button>
                    </Grid>
                </Grid>

                <Divider sx={{ my: 3 }} />

                <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                        <Input label="Input Padrão" placeholder="Digite algo..." />
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Input
                            label="Input com Erro"
                            placeholder="Digite algo..."
                            error={true}
                            errorMessage="Este campo é obrigatório"
                        />
                    </Grid>
                </Grid>
            </Box>
        </Container>
    );
};

export default About;