import React from 'react';
import { Container, Typography, Grid, Box, Divider } from '@mui/material';
import Dashboard from '../components/function-components/Dashboard';
import UserProfile from '../components/class-components/UserProfile';
import TodoList from '../components/class-components/TodoList';

const Home = () => {
    return (
        <Container maxWidth="lg">
            <Box sx={{ my: 4 }}>
                <Typography variant="h4" component="h1" gutterBottom align="center">
                    Demonstração de Componentes React
                </Typography>
                <Typography variant="subtitle1" gutterBottom align="center" color="text.secondary">
                    Exemplos de diferentes tipos de componentes React
                </Typography>
            </Box>

            <Divider sx={{ my: 4 }} />

            <Box sx={{ mb: 6 }}>
                <Typography variant="h5" gutterBottom>
                    Dashboard (Componente Funcional com Hooks)
                </Typography>
                <Dashboard />
            </Box>

            <Grid container spacing={4}>
                <Grid item xs={12} md={6}>
                    <Typography variant="h5" gutterBottom>
                        Perfil do Usuário (Componente de Classe)
                    </Typography>
                    <UserProfile />
                </Grid>
                <Grid item xs={12} md={6}>
                    <Typography variant="h5" gutterBottom>
                        Lista de Tarefas (Componente de Classe)
                    </Typography>
                    <TodoList />
                </Grid>
            </Grid>
        </Container>
    );
};

export default Home;